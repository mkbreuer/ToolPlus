T+ Addons Icons 

Copyright (C) 2017  Marvin.K.Breuer (MKB)

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.

You are not permitted to: Sell

    > selling any Icons (modified or not) by themselves or in a texture pack, material, shader, scale modelling papers (pre-printed or digital), scrapbooking pack, etc.;

You are free to:   Share &  Adapt 

    > Share: copy and redistribute the material in any medium or format

    > Adapt: remix, transform, and build upon the material 

    The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:
-----------------------------------

1 > Attribution :	

    > You must give appropriate credit, provide a link to the license, and indicate if changes were made.
 
    > You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

2 > NonCommercial 

3 > ShareAlike: 		

    > If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

4 > No additional restrictions: 	

    > You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.


Notices:
-----------
    > You do not have to comply with the license for elements of the material in the public domain or where your use is permitted by an applicable exception or limitation.
    > No warranties are given. 
    > The license may not give you all of the permissions necessary for your intended use. 
    > For example, other rights such as publicity, privacy, or moral rights may limit how you use the material.
