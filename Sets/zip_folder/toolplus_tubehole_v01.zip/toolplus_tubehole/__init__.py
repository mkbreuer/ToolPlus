# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and / or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 - 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "T+ TubeHole",
    "author": "MKB",
    "version": (0, 1, 0),
    "blender": (2, 7, 8),
    "location": "View3D > Tool Shelf [T] or Property Shelf [N] > TAb: T+ > Panel: Tubehole",
    "description": "create a hole or a tube on selected face",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "ToolPlus"}


# LOAD UI #
from toolplus_tubehole.xtras_gui    import (VIEW3D_TP_Xtras_Panel_TOOLS)
from toolplus_tubehole.xtras_gui    import (VIEW3D_TP_Xtras_Panel_UI)

# LOAD ICONS #
from . icons.icons              import load_icons
from . icons.icons              import clear_icons


# LOAD OPERATORS #
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'toolplus_tubehole'))


if "bpy" in locals():
    import imp
   
    imp.reload(ltcircle)    
    imp.reload(tubehole)    

    print("Reloaded multifiles")
    
else:
 
    from . import ltcircle    
    from . import tubehole     

    print("Imported multifiles")


# LOAD MODULS #  
import bpy
from bpy import*
from bpy.props import* 
from bpy.types import AddonPreferences, PropertyGroup



# UI REGISTRY #
def update_panel_position(self, context):
    try:
        bpy.utils.unregister_class(VIEW3D_TP_Xtras_Panel_UI)
        
        bpy.utils.unregister_class(VIEW3D_TP_Xtras_Panel_TOOLS)
        
    except:
        pass
    
    try:
        bpy.utils.unregister_class(VIEW3D_TP_Xtras_Panel_UI)

    except:
        pass
    
    if context.user_preferences.addons[__name__].preferences.tab_location == 'tools':
        
        VIEW3D_TP_Xtras_Panel_TOOLS.bl_category = context.user_preferences.addons[__name__].preferences.tools_category
       
        bpy.utils.register_class(VIEW3D_TP_Xtras_Panel_TOOLS)

    else:
        bpy.utils.register_class(VIEW3D_TP_Xtras_Panel_UI)





# ADDON PREFERENCES #
class TP_Panels_Preferences(AddonPreferences):
    bl_idname = __name__
    
    prefs_tabs = EnumProperty(
        items=(('location',   "Location",   "Location"),
               ('url',        "URLs",       "URLs")),
               default='location')

    # TAB LOACATION #         
    tab_location = EnumProperty(
        name = 'Panel Location',
        description = 'save user settings and restart blender after switching the panel location',
        items=(('tools', 'Tool Shelf', 'place panel in the tool shelf [T]'),
               ('ui', 'Property Shelf', 'place panel in the property shelf [N]')),
               default='tools', update = update_panel_position)


    # UPADTE: PANEL #
    tools_category = StringProperty(name = "TAB Category", description = "add name for a new category tab", default = 'T+', update = update_panel_position)


    def draw(self, context): 

        layout = self.layout
        
        # INFO #
        row= layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)
           


        # LOACATION #
        if self.prefs_tabs == 'location':
          
            box = layout.box().column(1)
             
            row = box.row(1) 
            row.label("Panel Location:")
            
            row = box.row(1)
            row.prop(self, 'tab_location', expand=True)
          
            box.separator() 
        
            row = box.row(1)            
            if self.tab_location == 'tools':
                
                box.separator() 
                
                row.prop(self, "tools_category")

            box.separator() 

            row = layout.row()
            row.label(text="! please reboot blender after changing the panel location !", icon ="INFO")
                       

        # WEB #
        if self.prefs_tabs == 'url':

            row = layout.row()
            #row.operator('wm.url_open', text = 'THREAD', icon = 'BLENDER').url = " "




# REGISTRY #
import traceback

def register():    
    try: bpy.utils.register_module(__name__)
    except: traceback.print_exc()
    
    update_panel_position(None, bpy.context)


def unregister():
    try: bpy.utils.unregister_module(__name__)
    except: traceback.print_exc()
    
if __name__ == "__main__":
    register()
        
        



            



