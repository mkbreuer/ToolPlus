# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8-80 compliant>

import bpy

class SmoothVerticesProps(bpy.types.PropertyGroup):
    data_path =(
        "preferences.addons['{0}'].preferences.smooth_vertices"
    ).format(__package__.split(".")[0])

    # Smooth Vertices Settings
    boundary_is_locked : bpy.props.BoolProperty(
        name = "Lock Boundary",
        description = "Lock vertices that are on the boundary of the mesh.",
        default = False
    )
    iterations : bpy.props.IntProperty(
        name = "Iterations",
        description = "Number of smoothing iterations",
        default = 1,
        min = 1,
        soft_max = 25
    )
    only_selected_are_affected : bpy.props.BoolProperty(
        name = "Selected Only",
        description = (
            "Limit the smoothing operation's effect to the selected  " +
            "vertices only."
        ),
        default = True
    )

    # UI Visibility
    settings_ui_is_visible : bpy.props.BoolProperty(
        name = "Settings UI Visibility",
        description = "Show/hide the Settings UI.",
        default = False
    )
