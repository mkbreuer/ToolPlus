# SnapSet
Full customizable buttons for snapping task

!! Attention !!

During the source code zip download, github adding a hyphen into the folder name: view3d_snapset-0.2.9

Blender cannot read this!

Open the zip and change the dash to a underscore view3d_snapset_0.2.9

If you zip it now and install it, everthing is fine!
