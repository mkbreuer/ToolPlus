# ##### BEGIN GPL LICENSE BLOCK #####
#
# (C) 2019 MKB
#
#  This program is free software; you can redistribute it and / or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 3
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 - 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
#


bl_info = {
    "name": "SnapSet",
    "author": "marvin.k.breuer (MKB)",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "3D View > Toolshelf Panel [N], Menu [SHIFT+W], Special [W], Header [!?]",
    "description": "snap set presets for 3d view",
    "warning": "",
    "wiki_url": "https://github.com/mkbreuer/ToolPlus",
    "category": "ToolPlus",
}


# LOAD MODULES #
import bpy
from bpy.props import *


# LOAD / RELOAD SUBMODULES #
import importlib
from . import developer_utils

# LOAD CUSTOM ICONS #
from . icons.icons  import load_icons
from . icons.icons  import clear_icons

from .ot_snapset        import *
from .ot_targets        import *
from .ui_panel          import *
from .ui_header         import *
from .ui_menu           import *
from .ui_menu_pie       import *
from .ui_menu_special   import *
from .ui_keymap         import *

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())


# PANEL TO CONTAINING THE TOOLS #
class VIEW3D_PT_SnapSet_Panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'View'
    bl_label = "SnapSet"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        
        draw_snapset_ui(self, context, layout)



# UPDATE TAB CATEGORY FOR PANEL IN THE TOOLSHELF #
panels = (
        VIEW3D_PT_SnapSet_Panel,
        )

def update_panel(self, context):
    message = "Template: Updating Panel locations has failed"
    try:
        for panel in panels:
            if "bl_rna" in panel.__dict__:
                bpy.utils.unregister_class(panel)

        for panel in panels:
            panel.bl_category = context.preferences.addons[__name__].preferences.category
            bpy.utils.register_class(panel)

    except Exception as e:
        print("\n[{}]\n{}\n\nError:\n{}".format(__name__, message, e))
        pass


# UPDATE TOOLS # not needed if we used bool props #
def update_snapset_tools(self, context):

    try:
        return True
    except:
        pass

    if context.preferences.addons[__name__].preferences.tab_display_tools == 'on':
        return True

    if context.preferences.addons[__name__].preferences.tab_display_tools == 'off':
        return None    


# ADDON PREFERENCES PANEL #
class Addon_Preferences_Snapset(bpy.types.AddonPreferences):
    bl_idname = __name__

    # INFO LIST #
    prefs_tabs : EnumProperty(
        items=(('panel',    "Panel",    "Panel"),
               ('menus',    "KeyMap",   "KeyMap")),
               default='panel')

    #------------------------------

    # PANEL #          
    category : StringProperty(
              name="Tab Category",
              description="Choose a name for the category of the panel",
              default="Tools",
              update=update_panel
              )

    tab_display_buttons_pl : EnumProperty(
        name = 'Buttons or Menus', 
        description = 'on = only butttons / off = use menus',
        items=(('off', 'Use Menus',   'enable tools in header'), 
               ('on',  'Use Buttons', 'disable tools in header')), 
        default='off', update = update_snapset_tools)

    tab_display_name_pl : EnumProperty(
        name = 'Name & Icon Toggle', 
        description = 'on / off',
        items=(('both_id', 'Show Name & Icon', 'keep names and icons visible in header menus'), 
               ('icon_id', 'Show only Icons',   'disable icons in header menus')), 
        default='both_id', update = update_snapset_tools)


    #------------------------------


    # MENU #
    tab_snapset_menu : EnumProperty(
        name = '3D View Menu',
        description = 'enable or disable menu for 3D View',
        items=(('menu',   'Use Menu', 'enable menu for 3D View'),
               ('pie',    'Use Pie',  'enable pie for 3D View'),
               ('remove', 'Disable',  'disable menus for 3D View')),
        default='menu', update = update_snapset_menu)


    # SUBMENUS #    
    tab_snapset_special : EnumProperty(
        name = 'Append to Special Menu',
        description = 'menu for special menu',
        items=(('append',   'Menu Bottom', 'add menus to default special menus'),
               ('prepend',  'Menu Top',    'add menus to default special menus'),
               ('remove',   'Menu Remove', 'remove menus from default menus')),
        default='remove', update = update_snapset_special)               


    #----------------------------


    # HEADER #
    expand_panel_tools : bpy.props.BoolProperty(name="Expand", description="Expand, to display the settings", default=False)    

    tab_snapset_header : EnumProperty(
        name = 'Header Menu',
        description = 'enable or disable menu for Header',
        items=(('add',    'Menu on',  'enable menu for Header'),
               ('remove', 'Menu off', 'disable menu for Header')),
        default='remove', update = update_snapset_header)

    tab_display_buttons : EnumProperty(
        name = 'Buttons or Menus', 
        description = 'on = only butttons / off = use menus',
        items=(('off', 'Use Menus',   'enable tools in header'), 
               ('on',  'Use Buttons', 'disable tools in header')), 
        default='off', update = update_snapset_tools)

    tab_display_name : EnumProperty(
        name = 'Name & Icon Toggle', 
        description = 'on / off',
        items=(('both_id', 'Show Name & Icon', 'keep names and icons visible in header menus'), 
               ('icon_id', 'Show only Icons',   'disable icons in header menus')), 
        default='both_id', update = update_snapset_tools)

    #----------------------------
    
    
    # DRAW PREFENCES #
    def draw(self, context):
        layout = self.layout
        
        # INFO #
        row= layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)


        # LOCATION #
        if self.prefs_tabs == 'panel':
            
            box = layout.box().column(align=True)

            row = box.row(align=True)
            sub = row.row()
            sub.scale_x = 0.5
            sub.label(text="Tab Category:")
            row.prop(self, "category", text="")       

            box.separator() 
            box.separator() 

            row = box.row()           
            row.label(text=" ")   
            row.prop(self, 'tab_display_buttons_pl',  expand=True)
       
            box.separator() 

            row = box.row()                  
            row.label(text=" ")   
            row.prop(self, 'tab_display_name_pl',  expand=True)

            box.separator() 
            box.separator() 

     
            

        # APPEND #
        if self.prefs_tabs == 'menus':

            col = layout.column(align=True)   

            box = col.box().column(align=True)
           
            box.separator()            
           
            row = box.row(align=True)    
            row.label(text="Append to Header", icon ="COLLAPSEMENU")       

            box.separator() 

            row = box.row(align=True)  
            row.prop(self, 'tab_snapset_header', expand=True)

            box.separator() 

            row = box.row()           
            row.prop(self, 'tab_display_buttons',  expand=True)
       
            box.separator() 

            row = box.row()                  
            row.prop(self, 'tab_display_name',  expand=True)

            box.separator() 
            box.separator() 
            
            #-----------------------------------------------------

            box = col.box().column(align=True)

            box.separator()
            
            row = box.row(align=True)  
            row.label(text="Cascade Menu: [SHIFT+W] ", icon ="COLLAPSEMENU")        

            box.separator() 

            row = box.row(align=True)  
            row.prop(self, 'tab_snapset_menu', expand=True)
         
            box.separator()
            box.separator()

            #-----------------------------------------------------

            box = col.box().column(align=True)
         
            box.separator()
         
            row = box.row(align=True)  
            row.label(text="Context Menu [W]", icon ="COLLAPSEMENU")         

            box.separator() 

            row = box.row(align=True)  
            row.prop(self, 'tab_snapset_special', expand=True)

            box.separator()
            box.separator()

            #-----------------------------------------------------

            box = col.box().column(align=True)
           
            box.separator()              

            # TIP #            
            row = box.row(align=True)             
            row.label(text="! For key change go to > Edit: Preferences > Keymap !", icon ="INFO")

            row = box.column(align=True) 
            row.label(text="1 > Change search to key-bindig and insert the hotkey: shift w", icon ="BLANK1")
            row.label(text="2 > Under 3D View you find the Call Menu: VIEW3D_TP_SnapSet_Menu or VIEW3D_TP_SnapSet_Menu_Pie!", icon ="BLANK1")
            row.label(text="3 > Choose a new key configuration and save Preferences !", icon ="BLANK1")

            box.separator()  

            row = box.row(align=True)             
            row.label(text="Or edit the keymap script directly:", icon ="INFO")

            box.separator()  

            row = box.row(align=True)  
            row.operator("tpc_ot.keymap_snapset", text = 'Open KeyMap in Text Editor')
            row.operator('wm.url_open', text = 'Type of Events').url = "https://github.com/mkbreuer/Misc-Share-Archiv/blob/master/images/SHORTCUTS_Type%20of%20key%20event.png?raw=true"
            
            box.separator()

            layout.separator()




# REGISTER #
classes = (
    VIEW3D_OT_KeyMap_Snapset,
    VIEW3D_OT_Snapset_Grid,
    VIEW3D_OT_Snapset_Place,
    VIEW3D_OT_Snapset_Retopo,
    VIEW3D_OT_Snapset_Active,
    VIEW3D_OT_Snapset_Cursor,
    VIEW3D_OT_Snapset_Closest,
    VIEW3D_OT_SnapSet_Compact,
    VIEW3D_OT_SnapSet_Batch_Dialog,
    VIEW3D_OT_PIVOT_TARGET,
    VIEW3D_OT_ORIENT_AXIS,
    VIEW3D_OT_SNAP_TARGET,
    VIEW3D_OT_SNAP_ELEMENT,
    VIEW3D_OT_SNAP_USE,
    VIEW3D_PT_SnapSet_Panel,
    VIEW3D_MT_SnapSet_Menu_Panel,
    VIEW3D_MT_SnapSet_Menu_Pencil,
    VIEW3D_MT_SnapSet_Menu_Special,
    VIEW3D_MT_SnapSet_Options_Menu,
    Addon_Preferences_Snapset,
)

import traceback
import bpy.utils.previews

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)
    except:
        traceback.print_exc()

    print("Registered {} with {} modules".format(bl_info["name"], len(modules)))

    update_panel(None, bpy.context)
    update_snapset_menu(None, bpy.context)
    update_snapset_special(None, bpy.context)
    update_snapset_header(None, bpy.context)
    update_snapset_tools(None, bpy.context)


def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)
    except:
        traceback.print_exc()

    print("Unregistered {}".format(bl_info["name"]))


if __name__ == "__main__":
    register()



