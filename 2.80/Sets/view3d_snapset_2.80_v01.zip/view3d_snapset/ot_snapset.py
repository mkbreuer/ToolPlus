# LOAD MODULE #
import bpy
from bpy import*
from bpy.props import*

from os.path import dirname
from . import ui_keymap

class VIEW3D_OT_KeyMap_Snapset(bpy.types.Operator):
    bl_idname = "tpc_ot.keymap_snapset"
    bl_label = "Open KeyMap (Text Editor)"
    bl_description = "open keymap file in the text editor"

    def execute(self, context):
        path = ui_keymap.__file__
        bpy.data.texts.load(path)
        return {"FINISHED"}



# SEPARATE OPERATORS #

class VIEW3D_OT_Snapset_Grid(bpy.types.Operator):
    """Absolute Grid"""
    bl_idname = "tpc_ot.snapset_grid"
    bl_label = "Absolute Grid..."
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)          
        row = box.column(align=True)      
        row.label(text="Snap: INCREMENT")     
        row.label(text="Target: GRID")   
        row.label(text="Pivot: BOUNDING BOX CENTER") 

    def execute(self, context):
        bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'}
        bpy.context.scene.tool_settings.use_snap_rotate = True
        bpy.context.scene.tool_settings.use_snap_rotate = False       
        return {'FINISHED'}


class VIEW3D_OT_Snapset_Place(bpy.types.Operator):
    """Place Objects > Normal Rotate"""
    bl_idname = "tpc_ot.snapset_place"
    bl_label = "Place Object..."
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)          
        row = box.column(align=True)      
        row.label(text="Snap: FACE")     
        row.label(text="Target: CLOSEST")   
        row.label(text="Pivot: ACTIVE ELEMENT") 

    def execute(self, context):            
        bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'FACE'}
        bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
        bpy.context.scene.tool_settings.use_snap_align_rotation = True
        bpy.context.scene.tool_settings.use_snap_project = True                
        return {'FINISHED'}


class VIEW3D_OT_Snapset_Retopo(bpy.types.Operator):
    """Mesh Retopo > Surface Snapping"""
    bl_idname = "tpc_ot.snapset_retopo"
    bl_label = "Mesh Retopo..."
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)          
        row = box.column(align=True)      
        row.label(text="Snap: FACE")     
        row.label(text="Target: CLOSEST")   
        row.label(text="Pivot: BOUNDING BOX CENTER") 

    def execute(self, context):            
        bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'FACE'}
        bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
        bpy.context.scene.tool_settings.use_snap_align_rotation = False          
        return {'FINISHED'}


class VIEW3D_OT_Snapset_Closest(bpy.types.Operator):
    """Snap to Closest > Bound Box"""
    bl_idname = "tpc_ot.snapset_closest"
    bl_label = "Snap Closest..."
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)          
        row = box.column(align=True)      
        row.label(text="Snap: VERTEX")     
        row.label(text="Target: CLOSEST")   
        row.label(text="Pivot: MEDIAN POINT") 

    def execute(self, context):                            
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
        bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
        bpy.context.scene.tool_settings.use_snap_align_rotation = False         
        return {'FINISHED'}


class VIEW3D_OT_Snapset_Active(bpy.types.Operator):
    """Snap to Active > Origin Snap"""
    bl_idname = "tpc_ot.snapset_active"
    bl_label = "Snap Active..."
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)  
        row = box.column(align=True)      
        row.label(text="Snap: VERTEX")     
        row.label(text="Target: ACTIVE")   
        row.label(text="Pivot: MEDIAN POINT") 

    def execute(self, context):            
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
        bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
        bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
        bpy.context.scene.tool_settings.use_snap_align_rotation = False
        return {'FINISHED'}




class VIEW3D_OT_Snapset_Cursor(bpy.types.Operator):
    """Set 3D Cursor to active or selected"""
    bl_idname = "tpc_ot.snapset_cursor"
    bl_label = "3d Cursor to..."
    bl_options = {'REGISTER', 'UNDO'}

    tpc_3dc : bpy.props.EnumProperty(
                 items=[("tpc_active"        ,"Active"      ,"Active"      ,"" , 1),                                     
                        ("tpc_select"        ,"Selected"    ,"Selected"    ,"" , 2)],
                        name = "3d Cursor to...", 
                        default = "tpc_active")

    def draw(self, layout):
        layout = self.layout
        
        box = layout.box().column(align=True)  
        
        row = box.row(align=True)
        row.alignment = 'CENTER'        
        row.prop(self, 'tpc_3dc',text=" ", expand =True)   

        box = layout.box().column(align=True)  
        row = box.column(align=True)      
        row.label(text="Snap: VERTEX")     
        if self.tpc_3dc =="tpc_active":
            row.label(text="Target: ACTIVE")   
        else:
            row.label(text="Target: SELECTED")   
        row.label(text="Pivot: 3D CURSOR") 

    def execute(self, context):            
        bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
        bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
        bpy.context.scene.tool_settings.use_snap_align_rotation = False
                        
        if self.tpc_3dc == "tpc_active": 
            bpy.ops.view3d.snap_cursor_to_active()

        if self.tpc_3dc == "tpc_select": 
            bpy.ops.view3d.snap_cursor_to_selected()            

        return {'FINISHED'}





class VIEW3D_OT_SnapSet_Compact(bpy.types.Operator):
    """SnapSet"""
    bl_idname = "tpc_ot.snapset_compact"
    bl_label = "SnapSet"
    bl_options = {'REGISTER', 'UNDO'}

    tpc_3dc : bpy.props.EnumProperty(
                 items=[("tpc_active_3d"    ,"Active"      ,"move cursor to active"          ,"" , 1),                                     
                        ("tpc_select_3d"    ,"Selected"    ,"cursor stays between selected"  ,"" , 2)],
                        name = "3d Cursor to ...", 
                        default = "tpc_active_3d")


    mode : bpy.props.StringProperty(default="")    
  
    #if "material" in self.mode:              
    #row.operator("scene.to_all", text="Selected").mode = "material, selected"
    #row.operator("scene.to_all", text="Children").mode = "material, children"   

    def draw(self, context):
        layout = self.layout.column(align=True)  

        if self.mode == "tpc_cursor":    

            box = layout.box().column(align=True)  
            
            row = box.row(align=True)
            row.alignment = 'CENTER'        
            row.prop(self, 'tpc_3dc',text=" ", expand =True)   


    def execute(self, context):

        bpy.context.scene.tool_settings.use_snap = True
  
        if self.mode == "tpc_grid":
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
            bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'}
            bpy.context.scene.tool_settings.use_snap_grid_absolute = True
            bpy.context.scene.tool_settings.use_snap_align_rotation = False            
            
        if self.mode == "tpc_place":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
            bpy.context.scene.tool_settings.snap_elements = {'FACE'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = True
            bpy.context.scene.tool_settings.use_snap_project = True
                        
        if self.mode == "tpc_retopo":
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
            bpy.context.scene.tool_settings.snap_elements = {'FACE'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False
                        
        if self.mode == "tpc_active":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'                    
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False       
  
        if self.tpc_snap == "tpc_closest":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'           
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False    

        if self.mode == "tpc_cursor":
            bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'       
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False   
           
            if self.tpc_3dc == "tpc_active_3d": 
                bpy.ops.view3d.snap_cursor_to_active()

            if self.tpc_3dc == "tpc_select_3d": 
                bpy.ops.view3d.snap_cursor_to_selected()                         
                
        return {'FINISHED'}




class VIEW3D_OT_SnapSet_Batch_Dialog(bpy.types.Operator):
    """SnapSet: window dialog batch operator"""
    bl_idname = "tpc_ot.snapset_batch_dialog"
    bl_label = "SnapSet"
    bl_options = {'REGISTER', 'UNDO'}

    tpc_3dc : bpy.props.EnumProperty(
                 items=[("tpc_active_3d"    ,"Active"      ,"move cursor to active"          ,"" , 1),                                     
                        ("tpc_select_3d"    ,"Selected"    ,"cursor stays between selected"  ,"" , 2)],
                        name = "3d Cursor to ...", 
                        default = "tpc_active_3d")


    tpc_snap : bpy.props.EnumProperty(
                 items=[("tpc_grid"        ,"Grid"      ,"snap absolute grid" ,"" , 1),                                       
                        ("tpc_place"       ,"Place"     ,"Place Object"       ,"" , 2),
                        ("tpc_cursor"      ,"Cursor"    ,"3d Cursor"          ,"" , 3),
                        ("tpc_retopo"      ,"Retopo"    ,"Mesh Retopo"        ,"" , 4),                                     
                        ("tpc_closest"     ,"Closest"   ,"Closest Vertex"     ,"" , 5),
                        ("tpc_active"      ,"Active"    ,"Active Vertex"      ,"" , 6)],
                        name = "SnapSets", 
                        default = "tpc_active")


    def draw(self, context):
        layout = self.layout.column(align=True)  

        box = layout.box().column(align=True)  
        
        row = box.row(align=True)
        row.alignment = 'CENTER'        
        row.prop(self, 'tpc_snap',text=" ", expand =True)                                            

        if self.tpc_snap == "tpc_cursor":    

            box.separator()
            
            row = box.row(align=True)
            row.alignment = 'CENTER'        
            row.prop(self, 'tpc_3dc',text=" ", expand =True)   


    def invoke(self, context, event):
        dpi_value = bpy.context.user_preferences.system.dpi        
        return context.window_manager.invoke_props_dialog(self, width=dpi_value*1.75, height=300)

    def execute(self, context):

        bpy.context.scene.tool_settings.use_snap = True
  
        if self.tpc_snap == "tpc_grid":
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
            bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'}
            bpy.context.scene.tool_settings.use_snap_grid_absolute = True
            bpy.context.scene.tool_settings.use_snap_align_rotation = False            
            
        elif self.tpc_snap == "tpc_place":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
            bpy.context.scene.tool_settings.snap_elements = {'FACE'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = True
            bpy.context.scene.tool_settings.use_snap_project = True
                        
        elif self.tpc_snap == "tpc_retopo":
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
            bpy.context.scene.tool_settings.snap_elements = {'FACE'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False
                        
        elif self.tpc_snap == "tpc_active":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'                    
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False       
  
        elif self.tpc_snap == "tpc_closest":
            bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'           
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'CLOSEST'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False    

        elif self.tpc_snap == "tpc_cursor":
            bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'       
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
            bpy.context.scene.tool_settings.snap_target = 'ACTIVE'
            bpy.context.scene.tool_settings.use_snap_align_rotation = False   
           
            if self.tpc_3dc == "tpc_active_3d": 
                bpy.ops.view3d.snap_cursor_to_active()

            if self.tpc_3dc == "tpc_select_3d": 
                bpy.ops.view3d.snap_cursor_to_selected()                         
                
        return {'FINISHED'}



