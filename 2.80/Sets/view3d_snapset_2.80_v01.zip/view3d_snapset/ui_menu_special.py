# LOAD MODUL #    
import bpy
from bpy import *
from bpy.props import *
from . icons.icons import load_icons  


# UI: SUB MENU SPECIAL # 
class VIEW3D_MT_SnapSet_Menu_Special(bpy.types.Menu):
    bl_label = "SnapSet"
    bl_idname = "tpc_mt.snapset_special"

    def draw(self, context):
        layout = self.layout
       
        icons = load_icons()   

        layout.operator_context = 'INVOKE_REGION_WIN' 

        layout.scale_y = 1.5

        button_snap_grid = icons.get("icon_snap_grid")
        layout.operator("tpc_ot.snapset_grid", text="Grid", icon_value=button_snap_grid.icon_id)
                    
        if context.mode == 'OBJECT':
            button_snap_place = icons.get("icon_snap_place")
            layout.operator("tpc_ot.snapset_place", text="Place", icon_value=button_snap_place.icon_id)

        else:
            button_snap_retopo = icons.get("icon_snap_retopo")
            layout.operator("tpc_ot.snapset_retopo", text="Retopo", icon_value=button_snap_retopo.icon_id)    
 
        button_snap_cursor = icons.get("icon_snap_cursor")           
        layout.operator("tpc_ot.snapset_cursor", text="Cursor3D", icon_value=button_snap_cursor.icon_id) 

        button_snap_closest = icons.get("icon_snap_closest")
        layout.operator("tpc_ot.snapset_closest", text="Closest", icon_value=button_snap_closest.icon_id)
        
        button_snap_active = icons.get("icon_snap_active")
        layout.operator("tpc_ot.snapset_active", text="Active", icon_value=button_snap_active.icon_id) 

       


def draw_snapset_item_special(self, context):
    layout = self.layout

    icons = load_icons()
  
    if context.preferences.addons[__package__].preferences.tab_snapset_special == 'append':
        layout.separator()      

    button_snap_set = icons.get("icon_snap_set")
    layout.menu("tpc_mt.snapset_special", text="SnapSet", icon_value=button_snap_set.icon_id)      
    
    if context.preferences.addons[__package__].preferences.tab_snapset_special == 'prepend':
        layout.separator()
      





