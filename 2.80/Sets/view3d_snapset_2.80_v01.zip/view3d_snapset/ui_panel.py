# LOAD UI #  
from view3d_snapset.ui_header  import VIEW3D_MT_SnapSet_Menu_Panel

# LOAD MODUL #    
import bpy
from bpy import *
from bpy.props import *
from . icons.icons import load_icons


def draw_snapset_ui(self, context, layout):

    icons = load_icons()
    
    layout.operator_context = 'INVOKE_REGION_WIN'    

    col = layout.column(align=True)
 
    box = col.box().column(align=True) 

    # USE BUTTONS #
    display_buttons_pl = context.preferences.addons[__package__].preferences.tab_display_buttons_pl
    if display_buttons_pl == 'on': 
       
       
        # NAMES / ICONS #  
        display_name_pl = context.preferences.addons[__package__].preferences.tab_display_name_pl
        if display_name_pl == 'both_id':  

            tx_snapset_active = "Active"
            tx_snapset_closet = "Closet"
            tx_snapset_cursor = "Cursor"
            tx_snapset_grid   = "Grid"
            tx_snapset_place  = "Place"
            tx_snapset_retopo = "Retopo"


        if display_name_pl == 'icon_id':  
   
            tx_snapset_active = " "
            tx_snapset_closet = " "
            tx_snapset_cursor = " "
            tx_snapset_grid   = " "
            tx_snapset_place  = " "
            tx_snapset_retopo = " "
 

        # OPTIONS #  
        if display_name_pl == 'both_id':  
            row = box.column(align=True)
        else:
            row = box.row(align=True)

        #row.scale_y = 1.5
    
        button_snap_grid = icons.get("icon_snap_grid")
        row.operator("tpc_ot.snapset_grid", text= tx_snapset_grid, icon_value=button_snap_grid.icon_id)
    
        if context.mode == 'OBJECT':
            button_snap_place = icons.get("icon_snap_place")
            row.operator("tpc_ot.snapset_place", text= tx_snapset_place, icon_value=button_snap_place.icon_id)

        else:
            button_snap_retopo = icons.get("icon_snap_retopo")
            row.operator("tpc_ot.snapset_retopo", text= tx_snapset_retopo, icon_value=button_snap_retopo.icon_id)    

        button_snap_cursor = icons.get("icon_snap_cursor")           
        row.operator("tpc_ot.snapset_cursor", text= tx_snapset_cursor, icon_value=button_snap_cursor.icon_id)                         

        button_snap_closest = icons.get("icon_snap_closest")
        row.operator("tpc_ot.snapset_closest", text= tx_snapset_closet, icon_value=button_snap_closest.icon_id) 

        button_snap_active = icons.get("icon_snap_active")
        row.operator("tpc_ot.snapset_active", text= tx_snapset_active, icon_value=button_snap_active.icon_id)



    # USE MENUS #
    else:

        # NAMES / ICONS #  
        display_name_pl = context.preferences.addons[__package__].preferences.tab_display_name_pl
        if display_name_pl == 'both_id':  
                                                
            tx_snapset = " SnapSet"
  
        if display_name_pl == 'icon_id':  
  
            tx_snapset = " "

       
        # OPTIONS #  
        row = box.row(align=True)

        if display_buttons_pl == 'off':  
            if display_name_pl == 'icon_id': 
                row.operator("tpc_ot.set_pivot", text=" ", icon="PIVOT_BOUNDBOX").tpc_pivot="BOUNDING_BOX_CENTER"
                row.operator("tpc_ot.set_pivot", text=" ", icon="PIVOT_CURSOR").tpc_pivot="CURSOR"
                row.operator("tpc_ot.set_pivot", text=" ", icon="PIVOT_ACTIVE").tpc_pivot="ACTIVE_ELEMENT"
                row.operator("tpc_ot.set_pivot", text=" ", icon="PIVOT_INDIVIDUAL").tpc_pivot="INDIVIDUAL_ORIGINS"
                row.operator("tpc_ot.set_pivot", text=" ", icon="PIVOT_MEDIAN").tpc_pivot="MEDIAN_POINT"  

        else:
            pass

        button_snap_set = icons.get("icon_snap_set") 
        row.menu("VIEW3D_MT_SnapSet_Menu_Panel", text= tx_snapset, icon_value=button_snap_set.icon_id) 



