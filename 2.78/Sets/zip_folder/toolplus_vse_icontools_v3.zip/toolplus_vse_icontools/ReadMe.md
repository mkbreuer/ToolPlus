# VSE_IconTools

> IconTools Addon for Blender Video Sequence Editor (VSE) 2.76+ 

> Functions to VSE Header

How to install:

1. Open Blender, go to File > UserPreferences 
 
2. Addons > Install from file.. > choose the VSE_IconTools-master.zip 

3. Under VSE > Enable the Addon and Save User Settings 

2. Go to Video Sequence Editor or switch to Video Editing Screen Layout 
 
5. Under View (Header): Enable all or separate VSE_IconTools Themes 

6. Have Fun! ;) 


[![VSE_IconTools Demo](https://img.youtube.com/vi/Hz2dCXEI9aU/0.jpg)](https://www.youtube.com/watch?v=Hz2dCXEI9aU)
[Demo] (https://www.youtube.com/watch?v=Hz2dCXEI9aU)
