This t+ origin addon is a standalone one but also a part of t+ align.
